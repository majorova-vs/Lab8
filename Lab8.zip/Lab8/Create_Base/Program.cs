﻿using System;
using System.Xml.Linq;

namespace Create_Base
{
    class Program
    {
        static void Main(string[] args)
        {
            BuildXmlDocWithLINQToXml();
         
        }
        private static void BuildXmlDocWithLINQToXml()
        {           
             XDocument doc = new XDocument(
                new XElement("DataBase",
                    new XElement("Medicine",
                        new XAttribute("DrugStoreId", "1"),
                        new XAttribute("MedicineName", "Aspirin"),
                        new XAttribute("DateArrival", "12.07.2019"),
                        new XElement("Amount", "12"),
                        new XElement("Price", "120"),                       
                        new XElement("StoragePeriod", "365")),
                    new XElement("Medicine",
                        new XAttribute("DrugStoreId", "23"),
                        new XAttribute("MedicineName", "Ibuprofen"),
                        new XAttribute("DateArrival", "03.02.2020"),
                        new XElement("Amount", "10"),
                        new XElement("Price", "200"),                     
                        new XElement("StoragePeriod", "365")),
                    new XElement("Medicine",
                        new XAttribute("DrugStoreId", "100"),
                        new XAttribute("MedicineName", "Advil"),
                        new XAttribute("DateArrival", "09.08.2019"),
                        new XElement("Amount", "82"),
                        new XElement("Price", "300"),
                        
                        new XElement("StoragePeriod", "400"))));
            //сохраняем наш документ
            doc.Save("bs.xml"); 



           
        }
    }
}
