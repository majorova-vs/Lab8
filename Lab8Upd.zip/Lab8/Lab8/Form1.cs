﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace Lab8
{
    public partial class Form1 : Form
    {

        // Название препарата должно начинаться с заглавной буквы
        // Номер аптеки любое число от 1 до 99999
        // Дата любая (год не больше текущего) 
        // 
        Form2 frm2;
        Form3 frm3;
        
        XDocument doc = XDocument.Load("bs.xml");
        
        Regex rgxname = new Regex(@"[A-Z].*");
        int currentYear = DateTime.Now.Year;
        public Form1()
        {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.FixedSingle;
        }
        private bool CheckFullData(string q1, string q2, string q3, string q4, string q5, string q6)
        {
            try
            {
                Regex rgx = new Regex(@"^[1-9][0-9]{0,4}$");
                if (!rgx.IsMatch(q1))
                {
                    MessageBox.Show("DrugStore ID is invalid");
                    return false;
                }
            }
            catch { }
            if (q2 != "")
            {
                if (!Char.IsLetter(DataBank.in2, 0))
                {
                    MessageBox.Show("Medicine name is invalid");
                    return false;
                }
            }
            else if (q2 == "")
            {
                MessageBox.Show("Medicine name is invalid");
                return false;
            }

            /*  if (rgxname.IsMatch(DataBank.in2))
              {
                  MessageBox.Show("Medicine name is invalid");
                  return false;
              }*/


            try
            {
                DateTime.Parse(q3);
                if (Int32.Parse(q3.Substring(6, 4)) > currentYear)
                {      
                    MessageBox.Show("Date is invalid");
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Date is invalid");
                return false;
            }
            try
            {
                Regex rgx = new Regex(@"^[1-9][0-9]{0,4}$");
                if (!rgx.IsMatch(q4))
                {
                    MessageBox.Show("Amount is invalid");
                    return false;
                }
            }
            catch { }
            try
            {
                Regex rgx = new Regex(@"^[1-9][0-9]{0,4}$");
                if (!rgx.IsMatch(q5))
                {
                    MessageBox.Show("Price is invalid");
                    return false;
                }
            }
            catch { }
            try
            {
                Regex rgx = new Regex(@"^[1-9][0-9]{0,4}$");
                if (!rgx.IsMatch(q6))
                {
                    MessageBox.Show("Storage period is invalid");
                    return false;
                }
            }
            catch { }
            return true;
        }
        private bool CheckData(string q1, string q2, string q3)
        {
            /*try
            {
                Int32.Parse(q1);
            }
            catch
            { 
                MessageBox.Show("DrugStore ID is invalid"); 
                return false; 
            }*/
            try
            {
                Regex rgx = new Regex(@"^[1-9][0-9]{0,4}$");
                if (!rgx.IsMatch(q1))
                {
                    MessageBox.Show("DrugStore ID is invalid");
                    return false;
                }
            }
            catch { }

            
            if (q2!="")
            {
                if (!Char.IsLetter(q2, 0))
                {
                    MessageBox.Show("Medicine name is invalid");
                    return false;
                }
            }
            else if (q2=="")
            {
                MessageBox.Show("Medicine name is invalid");
                return false;
            }
            try
            {
                DateTime.Parse(q3);
                if (Int32.Parse(q3.Substring(6, 4)) <= currentYear)
                    return true;
                else
                {
                    MessageBox.Show("Date is invalid");
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Date is invalid");
                return false;
            }
        
        }
        private void button1_Click(object sender, EventArgs e)
        {
           string  q1 = textBox1.Text;
           string q2 = textBox2.Text;
          string  q3 = textBox3.Text;
            FindRecord(q1, q2, q3);
        }
        private void FindRecord(string q1, string q2, string q3)
        {
            if (CheckData(q1, q2, q3))
            {
                if (!FindMatch(q1, q2, q3))
                {
                    IEnumerable<XElement> Medicine =
                     from el in doc.Root.Elements("Medicine")
                     where (string)el.Attribute("DrugStoreId") == q1 &&
                     (string)el.Attribute("MedicineName") == q2 &&
                    (string)el.Attribute("DateArrival") == q3
                     select el;
                    foreach (XElement el in Medicine)
                        DataBank.Output = DataBank.Output + el;
                    frm2 = new Form2();
                    frm2.Show();
                    DataBank.Output = "";
                }
                else MessageBox.Show("The record does not exist");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string q1 = textBox1.Text;
            string q2 = textBox2.Text;
            string q3 = textBox3.Text;
            DeleteRecord(q1, q2, q3);
            
        }
        private void DeleteRecord(string q1, string q2, string q3)
        {
            if (CheckData(q1, q2, q3))
            {
                if (!FindMatch(q1, q2, q3))
                {
                    IEnumerable<XElement> Medicine = doc.Root.Descendants("Medicine").Where(
                        t => t.Attribute("DrugStoreId").Value == q1
                        && t.Attribute("MedicineName").Value == q2
                        && t.Attribute("DateArrival").Value == q3).ToList();

                    foreach (XElement t in Medicine)
                        t.Remove();
                    ShowRecords();
                }
                else MessageBox.Show("The record does not exist");
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            frm3 = new Form3();
            
            if (frm3.ShowDialog()==DialogResult.OK)
                AddRecord();
        }
        
        private void AddRecord()
        {
            string q1 = DataBank.in1;
            string q2 = DataBank.in2;
            string q3 = DataBank.in3;
            string q4 = DataBank.in4;
            string q5 = DataBank.in5;
            string q6 = DataBank.in6;
            if (CheckFullData(q1,q2,q3,q4,q5,q6))
            {
                if (FindMatch(q1, q2, q3))
                {

                    XElement Medicine = new XElement("Medicine",
                         new XAttribute("DrugStoreId", DataBank.in1),
                                new XAttribute("MedicineName", DataBank.in2),
                                new XAttribute("DateArrival", DataBank.in3),
                                new XElement("Amount", DataBank.in4),
                                new XElement("Price", DataBank.in5),
                                new XElement("StoragePeriod", DataBank.in6));

                    doc.Root.Add(Medicine);
                    doc.Save("bs.xml");
                }
                else MessageBox.Show("The record already exists");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ShowRecords();
        }
        private void ShowRecords()
        {
            IEnumerable<XElement> Medicine =
               from el in doc.Root.Elements("Medicine")
               select el;
            foreach (XElement el in Medicine)
                DataBank.Output = DataBank.Output + el;
            frm2 = new Form2();
            frm2.Show();
            DataBank.Output = "";
        }

        private bool FindMatch(string q1, string q2, string q3)
        {
            string info="";
            IEnumerable<XElement> Medicine =
                 from el in doc.Root.Elements("Medicine")
                 where (string)el.Attribute("DrugStoreId") == q1 &&
                 (string)el.Attribute("MedicineName") == q2 &&
                (string)el.Attribute("DateArrival") == q3
                 select el;
            foreach (XElement el in Medicine)
                info += el;
            if (info == "")
                return true;
            else 
                return false;
        }
    }
}
