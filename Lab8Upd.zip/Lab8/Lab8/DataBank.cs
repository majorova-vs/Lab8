﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8
{
    public static class DataBank
    {
        public static string Output;
        public static string in1;
        public static string in2;
        public static string in3;
        public static string in4;
        public static string in5;
        public static string in6;
  
    }
}
